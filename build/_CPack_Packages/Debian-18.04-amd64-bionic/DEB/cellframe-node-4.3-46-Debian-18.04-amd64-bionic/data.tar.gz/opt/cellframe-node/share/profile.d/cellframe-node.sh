#!/bin/sh
export PATH="$PATH:/opt/cellframe-node/bin:/opt/cellframe-node/sbin"

"""
pycfhelpers - Python SDK wrapper module for CellFrame blockchain platform.

This package provides helper functions and classes for working with CellFrame blockchain.
Mandatory for each CellFrame plugin.

Note: This __init__.py file only provides package metadata.
All existing imports should continue to work as before:
    import cellframenet
    import helpers
    from logger import log
    etc.
"""

# Import version from package metadata (single source of truth)
try:
    from importlib.metadata import version
    __version__ = version("pycfhelpers")
except ImportError:
    # Fallback for Python < 3.8
    try:
        from importlib_metadata import version
        __version__ = version("pycfhelpers")
    except ImportError:
        # Last fallback - simple reading from pyproject.toml
        import os
        import re
        pyproject_path = os.path.join(os.path.dirname(__file__), "pyproject.toml")
        if os.path.exists(pyproject_path):
            try:
                with open(pyproject_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                # Look for version = "X.Y.Z"
                match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                __version__ = match.group(1) if match else "unknown"
            except Exception:
                __version__ = "unknown"
        else:
            __version__ = "unknown"

__author__ = "Demlabs"
__email__ = "support@demlabs.net"

# Check availability of various components
# This doesn't affect existing imports, only provides information

# Check CellFrame SDK
try:
    import CellFrame
    CELLFRAME_AVAILABLE = True
except ImportError:
    CELLFRAME_AVAILABLE = False

# Check Web3
try:
    import web3
    WEB3_AVAILABLE = True
except ImportError:
    WEB3_AVAILABLE = False

# Check Tornado
try:
    import tornado
    TORNADO_AVAILABLE = True
except ImportError:
    TORNADO_AVAILABLE = False

# DO NOT ADD ANY MODULE IMPORTS
# This preserves backward compatibility with existing code 
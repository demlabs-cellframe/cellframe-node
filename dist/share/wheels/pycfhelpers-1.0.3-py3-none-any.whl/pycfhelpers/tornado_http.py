import asyncio
import sys
import urllib

from DAP.Core import logIt
try:
    import tornado
except:
    logIt.warning("TORNADO not installed, external http-server will be unavailable")



import threading


def init_tornado_http(url, handler, port):
    """Initialize Tornado HTTP server.

    Args:
        url (str): URL pattern to listen to.
        handler (callable): Function to handle incoming requests.
        port (int): Port number to listen on.

    Raises:
        BaseException: If Tornado is not installed, external http-server will be unavailable.
    """
    if "tornado" not in sys.modules:
        raise BaseException("TORNADO not installed, external http-server will be unavailable")

    class Http:
        """Wrapper to emulate cellframe-node Http object.

        This class provides a wrapper to emulate the behavior of cellframe-node's Http object.
        It must return query string and write data to response.
        """

        def __init__(self, trnd):
            """Initialize the Http object.

            Args:
                trnd: The tornado RequestHandler object.
            """
            self.trnd = trnd

        @property
        def query(self):
            """Property: query string.

            Returns:
                str: Returns the query string.
            """
            return self.trnd.request.query

        def replyAdd(self, str):
            """Write data to the response.

            Args:
                str: string to write.
            """
            self.trnd.write(str)

    class HttpCode:
        """Wrapper to emulate cellframe-node http-responce-code object."""

        def __init__(self):
            """Initialize the HttpCode object."""
            pass

        def set(self, v):
            """Set the response code."""
            self.code = v

        def get(self):
            """Get the response code."""
            return self.code

    class MainHandler(tornado.web.RequestHandler):
        """Handles incoming HTTP requests."""

        def set_default_headers(self):
            """Set the default headers for HTTP response."""
            self.set_header("Content-Type", 'application/json')

        def get(self):
            """Handle GET requests."""
            http = Http(self)
            code = HttpCode()
            handler(http, code)
            self.set_status(code.get())
            self.finish()

    async def eventloop(url, handler, port):
        """Event loop for the Tornado HTTP server."""
        app = tornado.web.Application([
            (url, MainHandler),
        ])

        app.listen(port)
        await asyncio.Event().wait()

    print("Running asincio thread")
    x = threading.Thread(target=lambda: asyncio.run(eventloop(url, handler, port)))
    x.start()

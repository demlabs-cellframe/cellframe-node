"""Pytest configuration for pycfhelpers tests."""

import pytest
import sys
import os

# Add current directory to Python path for imports
sys.path.insert(0, os.path.abspath('.'))

@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Set up test environment."""
    # Ensure we're testing the local package, not installed one
    if '.' not in sys.path:
        sys.path.insert(0, '.')
    
    yield
    
    # Cleanup after tests
    pass

@pytest.fixture
def temp_dir(tmp_path):
    """Provide a temporary directory for tests."""
    return tmp_path

# Pytest configuration
def pytest_configure(config):
    """Configure pytest."""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests"
    )
    config.addinivalue_line(
        "markers", "security: marks tests as security-related"
    )
    config.addinivalue_line(
        "markers", "compatibility: marks tests as compatibility tests"
    ) 
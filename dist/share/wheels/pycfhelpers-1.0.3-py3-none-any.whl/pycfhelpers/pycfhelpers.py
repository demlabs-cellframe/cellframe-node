"""
pycfhelpers - Python SDK wrapper module for CellFrame blockchain platform.

This package provides helper functions and classes for working with CellFrame blockchain.
Mandatory for each CellFrame plugin.

Note: This __init__.py file only provides package metadata.
All existing imports should continue to work as before:
    import cellframenet
    import helpers
    from logger import log
    etc.
"""

# Import version from main __init__.py (single source)
try:
    from . import __version__
except ImportError:
    # Fallback if module is used directly
    try:
        from importlib.metadata import version
        __version__ = version("pycfhelpers")
    except ImportError:
        __version__ = "1.0.0"  # Last fallback

__author__ = "Demlabs"
__email__ = "support@demlabs.net"

# Check availability of various components
# This doesn't affect existing imports, only provides information

# Check CellFrame SDK
try:
    import CellFrame
    CELLFRAME_AVAILABLE = True
except ImportError:
    CELLFRAME_AVAILABLE = False

# Check Web3
try:
    import web3
    WEB3_AVAILABLE = True
except ImportError:
    WEB3_AVAILABLE = False

# Check Tornado
try:
    import tornado
    TORNADO_AVAILABLE = True
except ImportError:
    TORNADO_AVAILABLE = False

# DO NOT ADD ANY MODULE IMPORTS
# This preserves backward compatibility with existing code 